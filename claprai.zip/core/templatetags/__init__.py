# File: core/templatetags/__init__.py
# Location: C:\git\_clapri\core\templatetags\__init__.py